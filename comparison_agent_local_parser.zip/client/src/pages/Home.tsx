import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowUp, Check, CircleHelp, Download, ExternalLink, FileCheck2, FileText, Loader2, Link2, MoreHorizontal, Paperclip, Sparkles, Table2, UploadCloud } from "lucide-react";
import { Streamdown } from "streamdown";
import { useRef, useState } from "react";

type ChatMessage = { role: "assistant" | "user"; kind: "welcome" | "analysis" | "text" | "stream" | "result"; text: string };

type DocumentItem = { name: string; version: string; color: string; status: string; file?: File };

const initialMessages: ChatMessage[] = [
  { role: "assistant", kind: "welcome", text: "你好，我是法规智能体。\n我可以先对齐文档结构，再对比条款内容，抽取专业参数，并通过联网调研补充有来源的结论。" },
  { role: "user", kind: "text", text: "请帮我对比 GB 4785 草案、现行版和对应欧标，输出所有变化点，并告诉我哪些变化会影响产品设计。" },
  { role: "assistant", kind: "analysis", text: "我会按四步处理这项任务：\n1. 识别并对齐三个文档的章节结构；\n2. 逐条对比内容和条件；\n3. 抽取数值、单位、适用范围等专业参数；\n4. 联网核验发布状态与国际对应关系，并给出可追溯结论。" },
];

const baseDocuments: DocumentItem[] = [
  { name: "GB 4785 草案", version: "V4.3.5", color: "bg-[#f4ead4] text-[#9a6c28]", status: "已识别" },
  { name: "GB 4785 现行版", version: "2019", color: "bg-[#e7f1eb] text-[#397257]", status: "已识别" },
  { name: "对应欧标", version: "UN R48", color: "bg-[#e7eef5] text-[#47718e]", status: "待确认" },
];

const changes = [
  { id: "CHG-024", title: "第 5.3 节：适用范围新增区域性要求", type: "新增", severity: "高", oldText: "本标准适用于 M、N 和 O 类汽车及挂车。", newText: "本标准适用于 M、N 和 O 类汽车及挂车，并增加区域性要求。", impact: "需确认车型覆盖", source: "草案 p.1 §1 ↔ 现行版 p.12 §5.3" },
  { id: "CHG-021", title: "表 7：最大安装高度由 1,500 mm 调整为 1,600 mm", type: "数值变化", severity: "高", oldText: "最大安装高度：1,500 mm", newText: "最大安装高度：1,600 mm", impact: "影响灯具安装支架", source: "草案 p.24 表 7 ↔ 现行版 p.31 表 7" },
  { id: "CHG-019", title: "新增自动化驾驶系统标志灯（ADS）章节", type: "新增", severity: "中", oldText: "无对应条款", newText: "新增 7.8 ADS 标志灯及控制要求", impact: "影响控制器与整车布置", source: "草案 p.48 §7.8" },
];

const parameters = [
  { name: "最大安装高度", oldValue: "1,500", newValue: "1,600", unit: "mm", impact: "高", source: "表 7" },
  { name: "光学中心偏差", oldValue: "±2", newValue: "±1.5", unit: "°", impact: "中", source: "表 12" },
  { name: "ADS 标志灯数量", oldValue: "—", newValue: "2", unit: "个", impact: "高", source: "§7.8" },
];

const evidence = [
  { title: "草案发布状态", source: "国家标准全文公开系统", date: "2026-09-21", url: "待配置官方来源" },
  { title: "国际对应关系", source: "UNECE Regulations / UN R48", date: "2026-09-21", url: "待配置官方来源" },
];

function AssistantCard({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return <div className="mt-4 rounded-2xl border border-[#e7e7e7] bg-white shadow-[0_6px_24px_rgba(0,0,0,.035)]"><div className="flex items-center gap-2 border-b border-[#efefef] px-4 py-3 text-xs font-semibold text-[#3c3c3c]">{icon}<span>{title}</span><button className="ml-auto text-slate-400 hover:text-slate-700"><MoreHorizontal className="h-4 w-4" /></button></div><div className="p-4">{children}</div></div>;
}

function ComparePreview({ documents }: { documents: DocumentItem[] }) {
  return <AssistantCard title={`已识别 ${documents.length} 份法规文件`} icon={<FileCheck2 className="h-4 w-4 text-[#4d63c9]" />}><div className="space-y-2">{documents.map(doc => <div key={`${doc.name}-${doc.version}`} className="flex items-center gap-3 rounded-xl bg-[#fafafa] px-3 py-2.5"><div className={`flex h-8 w-8 items-center justify-center rounded-lg ${doc.color}`}><FileText className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="truncate text-xs font-medium text-[#333]">{doc.name}</p><p className="mt-0.5 text-[10px] text-slate-400">{doc.version}</p></div><span className={`rounded-full px-2 py-1 text-[10px] ${doc.status === "待解析" ? "bg-[#fff6df] text-[#a77b2a]" : "bg-[#edf7f0] text-[#397257]"}`}>{doc.status}</span></div>)}</div><div className="mt-4 flex items-center gap-2 rounded-xl bg-[#f4f5ff] px-3 py-2.5 text-[11px] text-[#5866a9]"><Sparkles className="h-3.5 w-3.5" />解析服务：本地原生文本解析 · 支持章节、页码、bbox 与引用定位</div></AssistantCard>;
}

function ProgressCard() {
  return <AssistantCard title="法规对比工作流" icon={<Sparkles className="h-4 w-4 text-[#d0953e]" />}><div className="grid grid-cols-3 gap-2">{["结构对齐", "内容对比", "联网结论"].map((label, index) => <div key={label} className={`rounded-xl border p-3 ${index <= 1 ? "border-[#cfd5fb] bg-[#f4f5ff]" : "border-[#ededed] bg-[#fafafa]"}`}><div className="flex items-center gap-2"><span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] ${index < 1 ? "bg-[#4d63c9] text-white" : index === 1 ? "bg-[#d0953e] text-white" : "bg-[#e6e6e6] text-slate-500"}`}>{index < 1 ? <Check className="h-3 w-3" /> : index + 1}</span><span className="text-[11px] font-medium text-[#3f3f3f]">{label}</span></div><p className="mt-3 text-[10px] leading-4 text-slate-400">{index === 0 ? "章节、表格和附录映射" : index === 1 ? "逐条识别新增与变化" : "来源、时间和影响结论"}</p></div>)}</div><div className="mt-4 flex items-center justify-between text-[11px] text-slate-400"><span>正在对比条款与专业参数…</span><span>68%</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#eeeeee]"><div className="h-full w-[68%] rounded-full bg-[#5968cc]" /></div></AssistantCard>;
}

function ComparisonTable({ onExport }: { onExport: () => void }) {
  return <AssistantCard title="变化点总表 · 3 项高影响变化" icon={<Table2 className="h-4 w-4 text-[#4d63c9]" />}><div className="mb-3 flex items-center justify-between"><p className="text-[11px] text-slate-500">已完成条款映射，点击证据定位可查看原文页码</p><Button onClick={onExport} variant="outline" className="h-8 rounded-lg border-[#dedede] px-2.5 text-[11px]"><Download className="mr-1.5 h-3.5 w-3.5" />导出参数</Button></div><div className="overflow-x-auto rounded-xl border border-[#ededed]"><table className="w-full min-w-[760px] text-left text-[11px]"><thead className="bg-[#fafafa] text-slate-400"><tr><th className="px-3 py-2.5">变化点</th><th className="px-3 py-2.5">旧文</th><th className="px-3 py-2.5">新文</th><th className="px-3 py-2.5">产品影响</th><th className="px-3 py-2.5">证据</th></tr></thead><tbody className="divide-y divide-[#efefef]">{changes.map(change => <tr key={change.id} className="align-top"><td className="px-3 py-3"><div className="flex items-center gap-1.5"><span className="font-semibold text-[#5968cc]">{change.id}</span><Badge className="border-0 bg-[#fff2e5] px-1.5 py-0.5 text-[9px] font-normal text-[#a76f2d]">{change.severity}</Badge></div><p className="mt-1 max-w-[170px] font-medium leading-4 text-[#333]">{change.title}</p></td><td className="max-w-[170px] px-3 py-3 leading-5 text-slate-500"><mark className="rounded bg-[#fff0f0] px-1 text-[#9e5c5c]">{change.oldText}</mark></td><td className="max-w-[170px] px-3 py-3 leading-5 text-slate-600"><mark className="rounded bg-[#eef8f0] px-1 text-[#397257]">{change.newText}</mark></td><td className="px-3 py-3 text-[#9a6c28]">{change.impact}</td><td className="px-3 py-3"><button onClick={() => toast.success(`已定位：${change.source}`)} className="flex items-center gap-1 text-[#5968cc] hover:underline"><ExternalLink className="h-3 w-3" />原文定位</button></td></tr>)}</tbody></table></div></AssistantCard>;
}

function ParameterCard({ onExport }: { onExport: () => void }) {
  return <AssistantCard title="专业参数抽取" icon={<Table2 className="h-4 w-4 text-[#397257]" />}><div className="flex items-center justify-between mb-3"><p className="text-[11px] text-slate-500">已抽取数值、单位、影响等级和来源定位</p><Button onClick={onExport} variant="outline" className="h-8 rounded-lg border-[#dedede] px-2.5 text-[11px]"><Download className="mr-1.5 h-3.5 w-3.5" />CSV</Button></div><div className="grid gap-2 md:grid-cols-3">{parameters.map(item => <div key={item.name} className="rounded-xl border border-[#e8eee9] bg-[#f7fbf8] p-3"><p className="text-[11px] font-medium text-[#355f45]">{item.name}</p><div className="mt-2 flex items-end gap-1"><span className="text-lg font-semibold text-[#202020]">{item.newValue}</span><span className="text-[10px] text-slate-500">{item.unit}</span></div><p className="mt-1 text-[10px] text-slate-400">旧值 {item.oldValue} · {item.source}</p></div>)}</div></AssistantCard>;
}

function ReportCard({ onDownload }: { onDownload: (format: "word" | "pdf") => void }) {
  return <AssistantCard title="正式法规对比报告" icon={<FileCheck2 className="h-4 w-4 text-[#5968cc]" />}><div className="rounded-xl bg-[#f7f8ff] p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-[#30385e]">GB 4785 草案变化总报告</p><p className="mt-1 text-[11px] text-[#737ba4]">包含变化点总表、原文定位、专业参数、联网证据和审核说明</p></div><Badge className="border-0 bg-[#e6e9ff] text-[10px] font-normal text-[#5968cc]">v0.1 草稿</Badge></div><div className="mt-4 flex flex-wrap gap-2"><Button onClick={() => onDownload("word")} className="h-8 rounded-lg bg-[#202020] px-3 text-xs hover:bg-black"><Download className="mr-1.5 h-3.5 w-3.5" />Word</Button><Button onClick={() => onDownload("pdf")} variant="outline" className="h-8 rounded-lg border-[#d5d8ec] bg-white px-3 text-xs"><Download className="mr-1.5 h-3.5 w-3.5" />PDF</Button><Button onClick={() => toast.success("报告已进入审核流程")} variant="outline" className="h-8 rounded-lg border-[#d5d8ec] bg-white px-3 text-xs"><Check className="mr-1.5 h-3.5 w-3.5" />提交审核</Button></div></div></AssistantCard>;
}

function reportPayload() {
  return { title: "GB 4785 草案法规对比总报告", sourceDocuments: baseDocuments.map(doc => ({ name: doc.name, version: doc.version })), summary: "草案相较现行版和对应欧标，识别到结构重排、适用范围补充、安装高度变化以及 ADS 标志灯新增要求。高影响事项需由认证和产品工程负责人确认。", changes: changes.map(item => ({ id: item.id, title: item.title, type: item.type, severity: item.severity, oldText: item.oldText, newText: item.newText, impact: item.impact, source: item.source })), parameters, evidence: evidence.map(item => ({ title: item.title, source: item.source, url: item.url, retrievedAt: item.date })) };
}

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);
  const [documents, setDocuments] = useState<DocumentItem[]>(baseDocuments);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sendStream = async (text: string) => {
    const history = messages.map(item => ({ role: item.role, content: item.text }));
    const response = await fetch("/api/agent/chat/stream", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ messages: [...history, { role: "user", content: text }] }) });
    if (!response.ok || !response.body) throw new Error(await response.text());
    const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ""; let answer = "";
    setMessages(prev => [...prev, { role: "assistant", kind: "stream", text: "" }]);
    while (true) { const { done, value } = await reader.read(); if (done) break; buffer += decoder.decode(value, { stream: true }); const lines = buffer.split("\n"); buffer = lines.pop() ?? ""; for (const line of lines) { if (!line.startsWith("data:")) continue; try { const event = JSON.parse(line.slice(5)); if (event.error) throw new Error(event.error); if (event.content) { answer += event.content; setMessages(prev => prev.map((item, index) => index === prev.length - 1 ? { ...item, text: answer } : item)); } } catch (error) { if (error instanceof Error && error.message !== "Unexpected end of JSON input") throw error; } } }
    setMessages(prev => [...prev, { role: "assistant", kind: "result", text: "已完成本轮分析。下面是结构化变化点、专业参数和正式报告入口。" }]);
  };

  const submit = async (value = input) => {
    const text = value.trim(); if (!text || running) return;
    setMessages(prev => [...prev, { role: "user", kind: "text", text }]); setInput(""); setRunning(true);
    try { await sendStream(text); } catch (error) { setMessages(prev => [...prev, { role: "assistant", kind: "result", text: `DeepSeek 流式服务暂不可用：${error instanceof Error ? error.message : "请检查环境配置"}\n\n你仍可以先使用下方的本地对比结果卡片和报告导出功能。` }]); } finally { setRunning(false); }
  };

  const uploadDocuments = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []); if (!files.length) return;
    for (const file of files) {
      setDocuments(prev => [...prev, { name: file.name, version: "上传文件", color: "bg-[#eeeefb] text-[#5968cc]", status: "待解析", file }]);
      const bytes = new Uint8Array(await file.arrayBuffer()); let binary = ""; for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index] ?? 0); const dataBase64 = btoa(binary);
      try { const response = await fetch("/api/agent/documents", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ fileName: file.name, mimeType: file.type || "application/octet-stream", dataBase64 }) }); const result = await response.json(); if (!response.ok) throw new Error(result.error); setDocuments(prev => prev.map(item => item.name === file.name ? { ...item, status: result.parserStatus === "complete" ? "解析完成" : "待 OCR 复核或解析异常" } : item)); toast.success(`${file.name} 已上传并进入解析流程`); } catch (error) { setDocuments(prev => prev.map(item => item.name === file.name ? { ...item, status: "上传失败" } : item)); toast.error(error instanceof Error ? error.message : "文件上传失败"); }
    }
  };

  const exportParameters = () => { const csv = ["参数,旧值,新值,单位,影响,来源", ...parameters.map(item => [item.name, item.oldValue, item.newValue, item.unit, item.impact, item.source].map(value => `"${value}"`).join(","))].join("\n"); const url = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" })); const link = document.createElement("a"); link.href = url; link.download = "法规专业参数.csv"; link.click(); URL.revokeObjectURL(url); toast.success("参数 CSV 已下载"); };
  const downloadReport = async (format: "word" | "pdf") => { try { const response = await fetch(`/api/agent/report/${format}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(reportPayload()) }); if (!response.ok) throw new Error(await response.text()); const blob = await response.blob(); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = format === "word" ? "法规对比报告.doc" : "法规对比报告.pdf"; link.click(); URL.revokeObjectURL(url); toast.success(`${format.toUpperCase()} 报告已下载`); } catch (error) { toast.error(error instanceof Error ? error.message : "报告生成失败"); } };

  return <div className="flex min-h-screen flex-col bg-[#fafafa]"><header className="sticky top-0 z-30 flex h-[68px] items-center justify-between border-b border-[#e8e8e8] bg-[#fafafa]/95 px-5 backdrop-blur md:px-8"><div className="flex items-center gap-3"><div className="hidden h-8 w-8 items-center justify-center rounded-lg bg-[#202020] text-white md:flex"><Sparkles className="h-4 w-4" /></div><div><p className="text-sm font-semibold tracking-tight text-[#202020]">GB 4785 草案变化总结</p><p className="mt-0.5 text-[10px] text-slate-400">法规对比任务 · {documents.length} 个文件</p></div></div><div className="flex items-center gap-1.5"><button onClick={() => toast("当前任务已保存到历史对话")} className="rounded-lg p-2 text-slate-400 hover:bg-white hover:text-[#202020]"><Link2 className="h-4 w-4" /></button><button onClick={() => toast("任务选项已打开")} className="rounded-lg p-2 text-slate-400 hover:bg-white hover:text-[#202020]"><MoreHorizontal className="h-4 w-4" /></button></div></header><div className="mx-auto flex w-full max-w-[920px] flex-1 flex-col px-4 md:px-8"><div className="flex-1 pb-40 pt-8 md:pt-10">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`mb-7 flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}><div className={`flex max-w-[820px] gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}>{message.role === "assistant" && <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#202020] text-white"><Sparkles className="h-4 w-4" /></div>}{message.role === "user" && <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#e4e4e4] text-xs font-semibold text-slate-600">我</div>}<div className={message.role === "user" ? "max-w-[620px] rounded-2xl rounded-tr-md bg-[#ededed] px-4 py-3 text-sm leading-6 text-[#333]" : "min-w-0 flex-1 pt-1"}>{message.kind === "stream" && message.text ? <Streamdown>{message.text}</Streamdown> : <p className="whitespace-pre-line text-sm leading-7 text-[#343434]">{message.text}</p>}{message.kind === "welcome" && <div className="mt-4 flex flex-wrap gap-2"><Badge className="border-0 bg-[#f0f1ff] font-normal text-[#5968cc]">结构优先</Badge><Badge className="border-0 bg-[#f7f0e2] font-normal text-[#a17432]">证据可追溯</Badge><Badge className="border-0 bg-[#edf5ef] font-normal text-[#397257]">人工可复核</Badge></div>}{message.kind === "analysis" && <ComparePreview documents={documents} />}{message.kind === "result" && <><ProgressCard /><ComparisonTable onExport={exportParameters} /><ParameterCard onExport={exportParameters} /><ReportCard onDownload={downloadReport} /></>}</div></div></div>)}{running && <div className="mb-7 flex gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#202020] text-white"><Sparkles className="h-4 w-4" /></div><div className="flex items-center gap-2 pt-2 text-xs text-slate-400"><Loader2 className="h-4 w-4 animate-spin" />DeepSeek 正在流式分析…</div></div>}<div className="mt-8 flex flex-wrap gap-2"><button onClick={() => submit("开始对比这三份法规，先给我结构差异")} className="rounded-full border border-[#e4e4e4] bg-white px-3.5 py-2 text-xs text-slate-600 shadow-sm hover:border-[#cfd5fb] hover:bg-[#f7f8ff]"><Sparkles className="mr-1.5 inline h-3.5 w-3.5 text-[#5968cc]" />法规对比</button><button onClick={() => submit("抽取所有和灯具安装高度、角度、尺寸有关的参数")} className="rounded-full border border-[#e4e4e4] bg-white px-3.5 py-2 text-xs text-slate-600 shadow-sm hover:border-[#cfd5fb] hover:bg-[#f7f8ff]"><Table2 className="mr-1.5 inline h-3.5 w-3.5 text-[#397257]" />参数抽取</button><button onClick={() => submit("联网核验草案的发布状态、实施时间和官方来源")} className="rounded-full border border-[#e4e4e4] bg-white px-3.5 py-2 text-xs text-slate-600 shadow-sm hover:border-[#cfd5fb] hover:bg-[#f7f8ff]"><ExternalLink className="mr-1.5 inline h-3.5 w-3.5 text-[#a17432]" />联网调研</button></div></div><div className="fixed bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-[#fafafa] via-[#fafafa] to-transparent pb-5 pt-10 md:left-[276px]"><div className="mx-auto max-w-[920px] px-4 md:px-8"><div className="overflow-hidden rounded-2xl border border-[#d9d9d9] bg-white shadow-[0_8px_30px_rgba(0,0,0,.08)] focus-within:border-[#9fa9e6] focus-within:ring-4 focus-within:ring-[#dfe2ff]"><Textarea value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void submit(); } }} placeholder="输入问题或任务，告诉我你要对比什么…" className="min-h-[68px] resize-none border-0 px-4 pb-2 pt-4 text-sm shadow-none focus-visible:ring-0" /><div className="flex items-center justify-between px-3 pb-3"><div className="flex items-center gap-1.5"><input ref={fileInputRef} type="file" multiple className="hidden" accept=".pdf,.doc,.docx,.xls,.xlsx,.txt" onChange={event => void uploadDocuments(event)} /><button onClick={() => fileInputRef.current?.click()} className="flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-slate-500 hover:bg-[#f4f4f4]"><Paperclip className="h-4 w-4" />添加法规</button><button onClick={() => toast("技能菜单：结构对齐、条款对比、参数抽取、联网调研") } className="flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-slate-500 hover:bg-[#f4f4f4]"><Sparkles className="h-4 w-4 text-[#5968cc]" />技能</button></div><button onClick={() => void submit()} disabled={!input.trim() || running} className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#202020] text-white transition hover:bg-black disabled:cursor-not-allowed disabled:bg-[#e0e0e0] disabled:text-slate-400"><ArrowUp className="h-4 w-4" /></button></div></div><p className="mt-2 text-center text-[10px] text-slate-400">DeepSeek 和联网来源需要在环境配置中填写密钥；文档解析与切分在本地完成。</p></div></div></div></div>;
}
