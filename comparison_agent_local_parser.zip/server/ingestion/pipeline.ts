export type ParsedBlockKind = "heading" | "paragraph" | "table" | "figure" | "footnote" | "appendix";

export type ParsedBlock = {
  stableKey: string;
  kind: ParsedBlockKind;
  level: number;
  title?: string;
  text: string;
  pageNumber?: number;
  bbox?: [number, number, number, number];
  confidence: number;
  children?: ParsedBlock[];
};

export type ParseRequest = { documentId: number; fileName: string; fileUrl: string; mimeType: string; language?: string };

export type ParseResult = {
  documentId: number;
  parser: "local";
  parserVersion: string;
  blocks: ParsedBlock[];
  warnings: string[];
  coverage: { pages: number; parsedPages: number; lowConfidencePages: number };
};

export interface DocumentParserAdapter {
  parse(request: ParseRequest): Promise<ParseResult>;
}

/**
 * The parser is intentionally local and deterministic. It follows the
 * AI_Engine ingestion boundary: validate and hash the source, parse native
 * text first, mark blank/image pages for OCR review, then chunk while keeping
 * page, bbox, section and confidence evidence attached to every chunk.
 */
export function chooseParser(mimeType: string): "local" {
  void mimeType;
  return "local";
}
