import { createHash } from "node:crypto";
import { unzipSync } from "fflate";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";
import type { ParseResult, ParsedBlock, ParsedBlockKind } from "./pipeline";

const HEADING_RE = /^(第\s*[一二三四五六七八九十百千万0-9]+[章节条]|[一二三四五六七八九十百千万]+[、.]|\d+(?:\.\d+){0,3}[、. ]|附录\s*[A-Z一二三四五六七八九十])/;
const PDF_SIGNATURE = Buffer.from("%PDF-");
const ZIP_SIGNATURE = Buffer.from([0x50, 0x4b, 0x03, 0x04]);

export type LocalChunk = ParsedBlock & { sectionPath: string[]; chunkIndex: number; sourceHash: string };

function normalizeText(value: string) {
  return value.replace(/\u0000/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

function detectKind(text: string): ParsedBlockKind {
  if (HEADING_RE.test(text) || text.length < 90 && /[:：]$/.test(text)) return "heading";
  if (/\|.*\|/.test(text) || /\t/.test(text)) return "table";
  return "paragraph";
}

function makeBlock(text: string, pageNumber: number, order: number, bbox?: [number, number, number, number], confidence = 1): ParsedBlock {
  return { stableKey: `p${pageNumber}-b${order}`, kind: detectKind(text), level: detectKind(text) === "heading" ? Math.min(6, (text.match(/\./g) ?? []).length + 1) : 0, title: detectKind(text) === "heading" ? text : undefined, text, pageNumber, bbox, confidence };
}

async function parsePdf(bytes: Uint8Array): Promise<{ blocks: ParsedBlock[]; pages: number; lowConfidencePages: number[] }> {
  const pdf = await getDocument({ data: bytes }).promise;
  const blocks: ParsedBlock[] = [];
  const lowConfidencePages: number[] = [];
  for (let pageIndex = 1; pageIndex <= pdf.numPages; pageIndex += 1) {
    const page = await pdf.getPage(pageIndex);
    const content = await page.getTextContent();
    const items = content.items.filter((item): item is typeof item & { str: string; transform: number[]; width: number; height: number } => "str" in item && "transform" in item && typeof item.str === "string");
    const rows: Array<{ y: number; text: string; bbox: [number, number, number, number] }> = [];
    for (const item of items) {
      const x = Number(item.transform[4] ?? 0); const y = Number(item.transform[5] ?? 0); const width = Number(item.width ?? 0); const height = Number(item.height ?? 0);
      const row = rows.find(candidate => Math.abs(candidate.y - y) <= 3);
      if (row) { row.text += `${row.text ? " " : ""}${item.str}`; row.bbox = [Math.min(row.bbox[0], x), Math.min(row.bbox[1], y), Math.max(row.bbox[2], x + width), Math.max(row.bbox[3], y + height)]; } else rows.push({ y, text: item.str, bbox: [x, y, x + width, y + height] });
    }
    rows.sort((a, b) => b.y - a.y);
    const pageText = normalizeText(rows.map(row => row.text).join("\n"));
    if (!pageText) { lowConfidencePages.push(pageIndex); continue; }
    rows.forEach((row, order) => { const text = normalizeText(row.text); if (text) blocks.push(makeBlock(text, pageIndex, order, row.bbox, 0.98)); });
  }
  return { blocks, pages: pdf.numPages, lowConfidencePages };
}

function parseXmlText(xml: string) {
  return normalizeText(xml.replace(/<w:tab\s*\/?\s*>/g, "\t").replace(/<w:br\s*\/?\s*>/g, "\n").replace(/<\/w:p>/g, "\n").replace(/<[^>]+>/g, " "));
}

function parseTextLike(bytes: Uint8Array, fileName: string) {
  let text = new TextDecoder().decode(bytes);
  if (ZIP_SIGNATURE.every((value, index) => bytes[index] === value)) {
    const files = unzipSync(bytes); const xml = files["word/document.xml"];
    if (xml) text = parseXmlText(new TextDecoder().decode(xml));
  }
  const lines = text.split(/\r?\n/).map(normalizeText).filter(Boolean);
  return lines.map((line, index) => makeBlock(line, 1, index, undefined, 0.92));
}

export function sha256(bytes: Uint8Array) {
  return createHash("sha256").update(bytes).digest("hex");
}

export function chunkBlocks(blocks: ParsedBlock[], sourceHash: string, maxChars = 1200, overlapChars = 160): LocalChunk[] {
  const chunks: LocalChunk[] = []; let sectionPath: string[] = []; let buffer = ""; let pageNumber = 1; let bbox: [number, number, number, number] | undefined; let chunkIndex = 0;
  const flush = () => { const text = normalizeText(buffer); if (!text) return; chunks.push({ stableKey: `${sourceHash.slice(0, 12)}-c${chunkIndex}`, kind: "paragraph", level: sectionPath.length, title: sectionPath.at(-1), text, pageNumber, bbox, confidence: 0.96, sectionPath: [...sectionPath], chunkIndex, sourceHash }); chunkIndex += 1; };
  const consume = (text: string, block: ParsedBlock) => {
    let remaining = text;
    while (remaining) {
      if (!buffer) { buffer = remaining.slice(0, maxChars); remaining = remaining.slice(maxChars); if (remaining) { flush(); buffer = buffer.slice(-overlapChars); } continue; }
      const available = maxChars - buffer.length - 1;
      if (remaining.length <= available) { buffer = `${buffer}\n${remaining}`; remaining = ""; continue; }
      if (available > 0) { buffer = `${buffer}\n${remaining.slice(0, available)}`; remaining = remaining.slice(available); }
      flush(); buffer = buffer.slice(-overlapChars);
    }
    pageNumber = block.pageNumber ?? pageNumber; bbox = block.bbox ?? bbox;
  };
  for (const block of blocks) {
    if (block.kind === "heading") { flush(); buffer = ""; sectionPath = [...sectionPath.slice(0, Math.max(0, block.level - 1)), block.title ?? block.text]; pageNumber = block.pageNumber ?? pageNumber; bbox = block.bbox; continue; }
    pageNumber = block.pageNumber ?? pageNumber; bbox = block.bbox ?? bbox;
    consume(block.text, block);
  }
  flush();
  return chunks;
}

export async function parseLocally(input: { fileName: string; mimeType: string; bytes: Uint8Array }): Promise<ParseResult & { chunks: LocalChunk[]; sourceHash: string }> {
  const sourceHash = sha256(input.bytes); const lower = input.fileName.toLowerCase();
  let blocks: ParsedBlock[]; let pages = 1; let lowConfidencePages: number[] = [];
  if (input.mimeType === "application/pdf" || lower.endsWith(".pdf") || Buffer.from(input.bytes.slice(0, 5)).equals(PDF_SIGNATURE)) { const result = await parsePdf(input.bytes); blocks = result.blocks; pages = result.pages; lowConfidencePages = result.lowConfidencePages; } else blocks = parseTextLike(input.bytes, input.fileName);
  const chunks = chunkBlocks(blocks, sourceHash);
  return { documentId: 0, parser: "local", parserVersion: "ai-engine-style-1.0", blocks, chunks, sourceHash, warnings: lowConfidencePages.length ? [`${lowConfidencePages.length} pages contain no native text and require OCR review`] : [], coverage: { pages, parsedPages: pages - lowConfidencePages.length, lowConfidencePages: lowConfidencePages.length } };
}
