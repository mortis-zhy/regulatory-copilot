import { describe, expect, it } from "vitest";
import { chunkBlocks, sha256 } from "./ingestion/localParser";
import type { ParsedBlock } from "./ingestion/pipeline";

describe("local AI_Engine-style parser utilities", () => {
  it("creates stable source hashes", () => {
    expect(sha256(new TextEncoder().encode("法规"))).toHaveLength(64);
    expect(sha256(new TextEncoder().encode("法规"))).toBe(sha256(new TextEncoder().encode("法规")));
  });

  it("keeps section path, page and bbox metadata on overlapping chunks", () => {
    const blocks: ParsedBlock[] = [
      { stableKey: "h1", kind: "heading", level: 1, title: "第1章 总则", text: "第1章 总则", pageNumber: 2, confidence: 0.98 },
      { stableKey: "p1", kind: "paragraph", level: 0, text: "适用范围与定义。".repeat(400), pageNumber: 2, bbox: [10, 20, 200, 40], confidence: 0.98 },
    ];
    const chunks = chunkBlocks(blocks, "a".repeat(64), 120, 20);
    expect(chunks.length).toBeGreaterThan(1);
    expect(chunks[0]?.sectionPath).toEqual(["第1章 总则"]);
    expect(chunks[0]?.pageNumber).toBe(2);
    expect(chunks[0]?.bbox).toEqual([10, 20, 200, 40]);
    expect(chunks[0]?.sourceHash).toBe("a".repeat(64));
  });
});
