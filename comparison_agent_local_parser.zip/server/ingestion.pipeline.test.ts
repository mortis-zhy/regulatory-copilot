import { describe, expect, it } from "vitest";
import { chooseParser } from "./ingestion/pipeline";

describe("document parser routing", () => {
  it("routes PDF files to the local native-text parser", () => {
    expect(chooseParser("application/pdf")).toBe("local");
  });

  it("routes Office files to the same local parser boundary", () => {
    expect(chooseParser("application/vnd.openxmlformats-officedocument.wordprocessingml.document")).toBe("local");
  });

  it("keeps the parser choice deterministic for text files", () => {
    expect(chooseParser("text/plain")).toBe("local");
  });
});
