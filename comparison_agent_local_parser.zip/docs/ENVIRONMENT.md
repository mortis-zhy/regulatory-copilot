# 环境配置说明

本项目采用 **AI_Engine 风格的本地文档解析与切分链路**，不依赖外部 RAG 解析服务。

处理顺序为：文件真实性校验 → SHA-256 内容指纹 → 对象存储归档 → PDF 原生文本块解析 → 空白页标记 OCR 复核 → 章节路径识别 → 保留页码/bbox/置信度的重叠切分 → 进入法规对比 Agent。

## 必填配置

| 变量 | 示例 | 说明 |
|---|---|---|
| `DEEPSEEK_API_KEY` | `sk-...` | DeepSeek API 密钥，仅在服务端使用 |
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com/v1` | OpenAI 兼容接口地址 |
| `DEEPSEEK_MODEL` | `deepseek-chat` | 对话模型；复杂分析可改为 `deepseek-reasoner` |

## WebDev 已提供配置

| 变量 | 说明 |
|---|---|
| `DATABASE_URL` | MySQL/TiDB 连接地址 |
| `BUILT_IN_FORGE_API_URL` | Manus 对象存储代理地址 |
| `BUILT_IN_FORGE_API_KEY` | Manus 对象存储服务密钥 |
| `JWT_SECRET` | 登录会话签名密钥 |
| `VITE_APP_ID`、`OAUTH_SERVER_URL` | Manus 登录配置 |

## 可选配置

| 变量 | 默认值 | 说明 |
|---|---|---|
| `REPORT_FONT_PATH` | `/usr/share/fonts/opentype/noto/NotoSansCJKsc-Light.otf` | PDF 中文字体路径；生产容器应安装或挂载 CJK 字体 |

## 本地解析策略

`server/ingestion/localParser.ts` 参考 AI_Engine 的 `enterprise_kb/ingestion/parser.py` 和 `service.py`：

1. 支持 PDF、DOCX、TXT、MD 等常见法规文件；PDF 校验 `%PDF-` 签名，Office Open XML 校验 ZIP 签名。
2. 使用 SHA-256 指纹区分文件版本，并通过对象存储保存原始文件。
3. PDF 优先使用 `pdfjs-dist` 提取原生文本，按页面、文本行、块序号和 bbox 保存证据。
4. 没有原生文本的页面不会被伪造为“已解析”，而是进入 `lowConfidencePages` 并提示 OCR 复核。
5. 识别“第 X 章/条”“1.2.3”“附录”等章节标题，生成 `sectionPath`。
6. 按 1,200 字符上限和 160 字符重叠窗口切分，所有 chunk 继续携带 `sourceHash`、页码、bbox、章节路径和置信度，便于原文定位与差异高亮。

## DeepSeek 流式接口

项目的 `POST /api/agent/chat/stream` 会将对话转发到 `${DEEPSEEK_BASE_URL}/chat/completions`，请求参数使用 OpenAI 兼容格式并设置 `stream: true`。前端按 SSE `data: {"content":"..."}` 增量渲染；服务端系统提示词要求模型区分原文事实、模型推断和待人工确认事项。

## 启动前检查

```bash
# 在部署环境中补充 DEEPSEEK_API_KEY；不要将真实 key 提交到 GitHub
pnpm install
pnpm check
pnpm test
pnpm build
pnpm dev
```

如果没有配置 DeepSeek，界面会显示服务配置错误而不会伪装成已完成的分析；文件解析和切分仍然可以本地执行。对于扫描件或图片型页面，系统会返回 OCR 复核提示，后续可接入企业内部 OCR 引擎，但不会让外部 RAG 服务代替解析。
