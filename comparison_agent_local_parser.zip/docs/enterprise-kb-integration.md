# Enterprise knowledge governance boundary

The web Agent borrows the document-ingestion discipline from `AI_Engine/backend/enterprise_kb`: ingestion is a deterministic service boundary, not a second conversational agent. It validates the source file, calculates a SHA-256 version fingerprint, archives the original, extracts native text, records page and geometry evidence, flags pages requiring OCR review, detects section paths, and creates overlapping evidence-aware chunks.

The comparison Agent owns the regulatory conversation, comparison orchestration, evidence display, parameter extraction, and report generation. The local parser owns only deterministic extraction and segmentation. This separation keeps the LLM from inventing source locations and allows a future internal OCR engine to be added behind a narrow adapter without introducing an external RAG platform.

## Processing boundary

1. Validate file size, extension, and native signature before parsing.
2. Store the original file using its SHA-256 content fingerprint.
3. Parse PDF native text into page/line blocks with block order and bbox metadata; parse DOCX XML and text-like files locally.
4. Detect headings such as chapters, clauses, numbered sections, and appendices, then maintain a `sectionPath` for every chunk.
5. Split at approximately 1,200 characters with a 160-character overlap while carrying source hash, page, bbox, confidence, and section path.
6. Mark pages without native text as OCR-review candidates rather than fabricating extracted content.

For the reference architecture, see the user-provided [AI_Engine repository](https://github.com/hulehanhulehan-glitch/AI_Engine), especially `backend/enterprise_kb/ingestion/parser.py` and `backend/enterprise_kb/ingestion/service.py`.
